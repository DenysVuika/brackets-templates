/* Application Sripts */

$(function () {
  'use strict';
});