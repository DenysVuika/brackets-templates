# quickstart-angular
Basic HTML5/Bootstrap/Angular.js template
